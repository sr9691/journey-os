# Journey Circle Creator - WordPress Plugin

**Version:** 1.0.0  
**Requires at least:** WordPress 5.8  
**Tested up to:** WordPress 6.4  
**PHP Version:** 7.4 or higher  
**License:** GPL-2.0+

## Description

Journey Circle Creator is a WordPress plugin that enables marketing agencies to create structured problem → solution → offer content ecosystems with AI-assisted content generation for their campaigns.

## Features

- **Service Areas**: Organize clients and services
- **Journey Circles**: Create complete content journeys with:
  - 5 Problems (outer ring)
  - 5 Solutions (middle ring, 1:1 mapped to problems)
  - Multiple Offers (center, multiple per solution)
- **Brain Content**: Upload source material (URLs, text, files)
- **AI Integration**: Generate content using Google Gemini (OpenAI coming soon)
- **Visual Canvas**: Interactive journey circle visualization
- **Industry Targeting**: RB2B industry taxonomy integration

## Installation

### Automated Installation

1. Download the `journey-circle.zip` file
2. Go to WordPress Admin → Plugins → Add New
3. Click "Upload Plugin" and select the zip file
4. Click "Install Now" and then "Activate"

### Manual Installation

1. Extract the zip file contents
2. Upload the `journey-circle` folder to `/wp-content/plugins/`
3. Activate the plugin through the 'Plugins' menu in WordPress

## Database Setup

The plugin automatically creates the following custom database tables on activation:

- `wp_jc_metadata` - Additional metadata storage
- `wp_jc_relationships` - Journey circle relationships
- `wp_jc_brain_content_data` - Brain content storage
- `wp_jc_ai_generated_content` - AI-generated content tracking

## Post Types

The plugin registers the following custom post types:

- `jc_service_area` - Service or product areas
- `jc_journey_circle` - Complete journey circles
- `jc_problem` - Problems (outer ring)
- `jc_solution` - Solutions (middle ring)
- `jc_offer` - Offers (center)
- `jc_brain_content` - Source material for AI

## Taxonomies

- `jc_industry` - Industry targeting (hierarchical)
- `jc_asset_type` - Content asset types (long article, short article, etc.)
- `jc_status` - Workflow status (draft, active, complete, etc.)

## Usage

### Creating a Journey Circle

1. **Create Service Area**
   ```php
   $service_area_manager = new Service_Area_Manager();
   $service_area_id = $service_area_manager->create([
       'title' => 'Cloud Migration Services',
       'description' => 'Enterprise cloud migration',
       'client_id' => 123
   ]);
   ```

2. **Add Brain Content**
   ```php
   $brain_manager = new Brain_Content_Manager();
   $brain_manager->add_content($service_area_id, [
       'type' => 'url',
       'value' => 'https://example.com/cloud-guide'
   ]);
   ```

3. **Create Journey Circle**
   ```php
   $journey_manager = new Journey_Circle_Manager();
   $journey_id = $journey_manager->create([
       'service_area_id' => $service_area_id,
       'industries' => [101, 102]
   ]);
   ```

4. **Add Problems (5 max)**
   ```php
   $problem_id = $journey_manager->add_problem($journey_id, [
       'title' => 'Legacy infrastructure costs',
       'description' => 'High maintenance costs',
       'is_primary' => true
   ]);
   ```

5. **Add Solutions (1 per problem)**
   ```php
   $solution_id = $journey_manager->add_solution($journey_id, $problem_id, [
       'title' => 'Cloud Migration Strategy',
       'description' => 'Migrate to AWS'
   ]);
   ```

6. **Add Offers (multiple per solution)**
   ```php
   $offer_id = $journey_manager->add_offer($journey_id, $solution_id, [
       'title' => 'Free Consultation',
       'url' => 'https://example.com/consultation'
   ]);
   ```

## Development

### Requirements

- PHP 7.4+
- WordPress 5.8+
- Composer (for development)
- PHPUnit (for testing)

### Setting Up Development Environment

```bash
# Install dependencies
composer install

# Run tests
./vendor/bin/phpunit tests/

# Run code sniffer
./vendor/bin/phpcs --standard=WordPress includes/
```

### Running Tests

The plugin includes comprehensive PHPUnit tests:

```bash
# Run all tests
./vendor/bin/phpunit

# Run specific test class
./vendor/bin/phpunit tests/test-journey-circle.php

# Run with coverage
./vendor/bin/phpunit --coverage-html coverage/
```

### Test Coverage

Current test coverage includes:
- ✅ Custom post type registration
- ✅ Custom taxonomy registration
- ✅ Service area CRUD operations
- ✅ Journey circle creation and validation
- ✅ Problem/solution/offer relationships
- ✅ Brain content management
- ✅ Data validation and error handling
- ✅ Complete workflow integration

## API Reference

### Service Area Manager

```php
$manager = new Service_Area_Manager();

// Create
$id = $manager->create($args);

// Read
$service_area = $manager->get($id);
$service_areas = $manager->get_by_client($client_id);

// Update
$manager->update($id, $args);

// Delete
$manager->delete($id);
```

### Journey Circle Manager

```php
$manager = new Journey_Circle_Manager();

// Create journey circle
$journey_id = $manager->create([
    'service_area_id' => $service_area_id
]);

// Add components
$problem_id = $manager->add_problem($journey_id, $args);
$solution_id = $manager->add_solution($journey_id, $problem_id, $args);
$offer_id = $manager->add_offer($journey_id, $solution_id, $args);

// Retrieve
$journey = $manager->get($journey_id);
$problems = $manager->get_problems($journey_id);
$solutions = $manager->get_solutions($journey_id);
$offers = $manager->get_offers($journey_id);
```

### Brain Content Manager

```php
$manager = new Brain_Content_Manager();

// Add content
$content_id = $manager->add_content($service_area_id, [
    'type' => 'url', // or 'text', 'file'
    'value' => 'https://example.com'
]);

// Upload file
$content_id = $manager->upload_file($service_area_id, $_FILES['upload']);

// Retrieve
$content = $manager->get_by_service_area($service_area_id);

// Delete
$manager->delete($content_id);
```

## Configuration

### Settings

Access settings at: **WordPress Admin → Journey Circle → Settings**

Available settings:
- **Enable AI**: Toggle AI content generation
- **AI Provider**: Google Gemini (OpenAI coming soon)
- **AI API Key**: Your API key for the selected provider
- **Max Problems**: Maximum problems per journey (default: 5)
- **Max Solutions**: Maximum solutions per journey (default: 5)

### Hooks & Filters

The plugin provides hooks for customization:

```php
// Before journey circle is created
add_action('jc_before_create_journey', function($args) {
    // Custom logic
}, 10, 1);

// After journey circle is created
add_action('jc_after_create_journey', function($journey_id, $args) {
    // Custom logic
}, 10, 2);

// Filter AI-generated content
add_filter('jc_ai_generated_content', function($content, $type) {
    // Modify content
    return $content;
}, 10, 2);
```

## Troubleshooting

### Database Tables Not Created

If tables aren't created during activation:

1. Deactivate and reactivate the plugin
2. Check WordPress database user permissions
3. Manually run the SQL from `includes/class-journey-circle-activator.php`

### Custom Post Types Not Showing

1. Go to **Settings → Permalinks**
2. Click "Save Changes" (flushes rewrite rules)
3. Refresh your browser

### AI Not Working

1. Verify AI is enabled in settings
2. Check API key is correct
3. Ensure you have internet connectivity
4. Check error logs for API errors

## Changelog

### 1.0.0 - 2026-02-08

#### Added
- Initial release
- Custom post types for journey circles
- Service area management
- Problem/solution/offer relationships
- Brain content upload system
- Custom taxonomies
- Admin dashboard
- Settings page
- Comprehensive PHPUnit tests
- Data validation and error handling

## Roadmap

### Phase 2 (Iterations 4-7)
- [ ] Complete 11-step workflow UI
- [ ] Canvas visualization
- [ ] Real-time state management
- [ ] Auto-save functionality

### Phase 3 (Iterations 8-9)
- [ ] Google Gemini AI integration
- [ ] Problem/solution title generation
- [ ] Content outline generation
- [ ] Full content generation
- [ ] Voice feedback support

### Phase 4 (Iterations 10-11)
- [ ] Export and linking workflow
- [ ] Completion validation
- [ ] Mobile responsive design
- [ ] Cross-browser testing
- [ ] Performance optimization
- [ ] Security audit

### Future Enhancements
- [ ] OpenAI integration
- [ ] Template library
- [ ] Collaboration features
- [ ] Version history
- [ ] Analytics dashboard
- [ ] A/B testing support

## Support

For support, please:
1. Check the documentation
2. Search existing issues on GitHub
3. Create a new issue with detailed information

## Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Write tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

This plugin is licensed under the GPL-2.0+ license.

## Credits

- Developed for DirectReach Campaign Builder
- Uses Google Gemini API for AI content generation
- Built with WordPress best practices

---

**Author:** DirectReach  
**Website:** https://directreach.com  
**Documentation:** https://docs.directreach.com/journey-circle
